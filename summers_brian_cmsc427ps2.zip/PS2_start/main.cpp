/****************************************************************************
**
CMSC427 Spring 2015 Problem Set 2
Brian Summers - 110656609
summers.brian.cs@gmail.com
3/5/2015

Uses start code by:
Main for OpenGL in QT.
Start code for CMSC 427, Spring 2015
Reference: cube & texture example in Qt Creator
author: Zheng Xu, xuzhustc@gmail.com
**
****************************************************************************/

#ifndef QT_NO_OPENGL
#include "mywidget.h"
#endif

#include <QApplication>
#include <QSurfaceFormat>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QSurfaceFormat format;
    format.setDepthBufferSize(24);
    format.setVersion(3, 3);
    format.setProfile(QSurfaceFormat::CoreProfile);
    QSurfaceFormat::setDefaultFormat(format);

    app.setApplicationName("Car 101");
#ifndef QT_NO_OPENGL
    MyWidget myW;
    myW.show();
#else
    QLabel note("OpenGL Support required");
    note.show();
#endif
    return app.exec();
}
