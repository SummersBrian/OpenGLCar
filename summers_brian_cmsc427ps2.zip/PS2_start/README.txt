CMSC427 Spring 2015
Brian Summers - 110656609

This problem set 2 was developed on a Windows environment with VS2013, QT 5.4.0 with QT creator.
Using the start code provided for problem set 2, I opened the project file and edited the .cpp and .h
files and coded in C++ in order to complete the assignment. Nothing fancy was used or done, so importing,
building, and running should be simple.
